﻿$lngSuccessNum = 0
$lngFailureNum = 99

#+-----------------------------------------------------------------------------
#+ function settings
#+-----------------------------------------------------------------------------
function printMsg($lngNum, $strMsg){
    switch ($lngNum) {
        0 { Write-Host ("Success : " + $strMsg) }
        Default { Write-Host ("Failure : " + $strMsg) }
    }
}

function setExistPassList(){
    Param(
        [string]$strDirPath
    )

    $arrList = @()

    Get-ChildItem -Recurse -File -Path $strDirPath | Where-Object{$_.Name -Like 'pass-*.ttl'} | %{
        $strTmpFileName = $_.Name.ToString()
        $arrList += ($strTmpFileName.split('.'))[0].split('-')[1]
    }
    return $arrList

}
function setExistSrvList() {
    Param(
        [string]$strListFile,
        $arrList
    )

    #+-------------------------------------
    #+ 1.Checking for file existence
    #+-------------------------------------
    if(! (Test-Path $strListFile) ){return $lngFailureNum}

    #+-------------------------------------
    #+ 2.Read a list file and store its contents in an associative array
    #+-------------------------------------
    $strTmpListData = Get-Content -Path $strListFile
    $arrTmpList = $strTmpListData.split('`r`n')

    $arrTmpList | ForEach-Object{
        $strTmpLine = $_
        $arrTmpLine = $strTmpLine.split(',')
        $arrList[$arrTmpLine[0]] = @{
            IP = $arrTmpLine[1];
            FLG = $arrTmpLine[2];
        }
    }

    return $lngSuccessNum
}

function labelConfig($txt, $fontSize, $xAxis, $yAxis){
    $conf= New-Object System.Windows.Forms.Label
    $conf.Location = New-Object System.Drawing.Point($xAxis,$yAxis)
    $conf.AutoSize = $True
    $conf.Text = $txt
    $itemFont = New-Object System.Drawing.Font(“メイリオ”,$fontSize,[System.Drawing.FontStyle]::Bold)
    $conf.Font = $itemFont
    return $conf
}

function txtBoxConfig($xAxis, $yAxis, $xSize, $ySize){
    $conf= New-Object System.Windows.Forms.TextBox
    $conf.Location = New-Object System.Drawing.Point($xAxis,$yAxis)
    $conf.Size = New-Object System.Drawing.Size($xSize,$ySize)
    return $conf
}

function comboBoxConfig($xAxis, $yAxis, $xSize, $ySize){
    $conf= New-Object System.Windows.Forms.ComboBox
    $conf.Location = New-Object System.Drawing.Point($xAxis,$yAxis)
    $conf.Size = New-Object System.Drawing.Size($xSize,$ySize)
    $conf.DropDownStyle = "DropDown"
    $conf.FlatStyle = "standard"
    return $conf
}

function showLoginDialog(){
    Param(
        [string[]]$arrPassList,
        [hashtable]$arrSrvList,
        [string]$strSrvLstFilePath
    )
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $lngAddFlg = 0

    # フォームの作成
    $form = New-Object System.Windows.Forms.Form
    $form.Text = "ログイン"
    $form.Size = New-Object System.Drawing.Size(400,320)

    # ラベルの設定
    $label = New-Object System.Windows.Forms.Label
    $label.Location = New-Object System.Drawing.Point(10,10)
    $label.AutoSize = $True
    $label.TextAlign = "TopLeft"
    $label.Text = "1.ログイン情報の入力"
    $Font1 = New-Object System.Drawing.Font(“Meiryo UI”,15,[System.Drawing.FontStyle]::Bold)
    $label.Font = $Font1

    #入力情報
    $targetLabel = labelConfig "ログイン先" 10 40 50
    $targetTextBox = comboBoxConfig 145 50 200 50
    foreach($key in $arrSrvList.Keys){$targetTextBox.Items.Add($key)}

    $targetLabel2 = labelConfig "ログファイル名" 10 40 80
    $targetTextBox2 = txtBoxConfig 145 80 200 50
    
    $targetLabel3 = labelConfig "IP" 10 40 110
    $targetTextBox3 = txtBoxConfig 145 110 200 50

    $targetLabel4 = labelConfig "ログイン情報" 10 40 140
    $targetTextBox4 = comboBoxConfig 145 140 200 50
    $arrPassList | ForEach-Object{$targetTextBox4.Items.Add($_)}

    $targetTextBox.Add_TextChanged({
        #テキストボックスの値から探る
        if($arrSrvList.ContainsKey($targetTextBox.Text)){
            $targetTextBox3.BackColor = "#FFFFFF"
            $targetTextBox3.Text = $arrSrvList[$targetTextBox.Text]['IP']
            $targetTextBox4.BackColor = "#FFFFFF"
            $targetTextBox4.Text = $arrSrvList[$targetTextBox.Text]['FLG']
        }
        else{
            $targetTextBox.BackColor = "#00FFFF"
            $targetTextBox3.BackColor = "#00FFFF"
            $targetTextBox3.Text = ""
            $targetTextBox4.BackColor = "#00FFFF"
            $targetTextBox4.Text = ""
        }
    })

    # ラベルの設定
    $label2 = New-Object System.Windows.Forms.Label
    $label2.Location = New-Object System.Drawing.Point(10,170)
    $label2.AutoSize = $True
    $label2.TextAlign = "TopLeft"
    $label2.Text = "2.画面色"
    $Font1 = New-Object System.Drawing.Font(“Meiryo UI”,15,[System.Drawing.FontStyle]::Bold)
    $label2.Font = $Font1

    #ラジオボタン
    $RadioButton = New-Object System.Windows.Forms.RadioButton
    $RadioButton.Location = New-Object System.Drawing.Point(40,200)
    $RadioButton.size = New-Object System.Drawing.Size(80,30)
    $RadioButton.Checked = $True
    $RadioButton.Text = "Expert"
    $RadioButton2 = New-Object System.Windows.Forms.RadioButton
    $RadioButton2.Location = New-Object System.Drawing.Point(130,200)
    $RadioButton2.size = New-Object System.Drawing.Size(80,30)
    $RadioButton2.Checked = $False
    $RadioButton2.Text = "Green"
    $RadioButton3 = New-Object System.Windows.Forms.RadioButton
    $RadioButton3.Location = New-Object System.Drawing.Point(210,200)
    $RadioButton3.size = New-Object System.Drawing.Size(80,30)
    $RadioButton3.Checked = $False
    $RadioButton3.Text = "Blue"
    $RadioButton4 = New-Object System.Windows.Forms.RadioButton
    $RadioButton4.Location = New-Object System.Drawing.Point(290,200)
    $RadioButton4.size = New-Object System.Drawing.Size(80,30)
    $RadioButton4.Checked = $False
    $RadioButton4.Text = "Purple"

    $OKButton = new-object System.Windows.Forms.Button
    $OKButton.Location = New-Object System.Drawing.Point(55,240)
    $OKButton.Size = New-Object System.Drawing.Size(80,30)
    $OKButton.Text = "ログイン"
    $OKButton.DialogResult = "OK"

    $CancelButton = new-object System.Windows.Forms.Button
    $CancelButton.Location = New-Object System.Drawing.Point(240,240)
    $CancelButton.Size = New-Object System.Drawing.Size(80,30)
    $CancelButton.Text = "キャンセル"
    $CancelButton.DialogResult = "Cancel"


    $Form.Controls.AddRange(@($label,$targetLabel,$targetTextBox,$targetLabel2,$targetTextBox2,$targetLabel3,$targetTextBox3,$targetLabel4,$targetTextBox4,$label2,$RadioButton,$RadioButton2,$RadioButton3,$RadioButton4,$OKButton,$CancelButton))
    $result = $form.ShowDialog()

    if($result -eq "キャンセル"){
        return @(1,@{})
    }

    #リストファイルに組込し、必要情報を返す    
    if($arrSrvList.ContainsKey($targetTextBox.Text)){
        $arrSrvList[$targetTextBox.Text]['IP'] = $targetTextBox3.Text
        $arrSrvList[$targetTextBox.Text]['FLG'] = $targetTextBox4.Text
    }
    else{
        $arrSrvList[$targetTextBox.Text] =@{
            IP = $targetTextBox3.Text;
            FLG = $targetTextBox4.Text;
        }
    }

    $arrTmpList = @()
    foreach($key in $arrSrvList.Keys){
        $arrTmpList += ($key + "," + $arrSrvList[$key]['IP'] + "," + $arrSrvList[$key]['FLG'])
    }
    $arrTmpSortedList = $arrTmpList | Sort-Object
    $arrTmpSortedList -join "`r`n" | Out-File -FilePath $strSrvLstFilePath -Encoding utf8 -NoNewline
    

    return @(0,@{
        IP  = $targetTextBox3;
        LOG = $targetTextBox2;
        FLG = $targetTextBox4;
    })
}